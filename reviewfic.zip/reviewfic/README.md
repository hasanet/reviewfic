# reviewfic
A plugin to create and manage client reviews with custom post types and shortcodes.
